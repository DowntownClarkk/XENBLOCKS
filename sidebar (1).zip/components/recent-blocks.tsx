import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Blocks, Check, Clock } from "lucide-react"

// Sample data
const recentBlocks = [
  {
    id: "0x8f72d1",
    timestamp: "2 mins ago",
    reward: "0.25 XEN",
    difficulty: "0.8",
    status: "confirmed",
    miner: "0x3a7b...e92f",
  },
  {
    id: "0x6e45c2",
    timestamp: "15 mins ago",
    reward: "0.25 XEN",
    difficulty: "0.8",
    status: "confirmed",
    miner: "0x3a7b...e92f",
  },
  {
    id: "0x9d23b4",
    timestamp: "32 mins ago",
    reward: "0.25 XEN",
    difficulty: "0.9",
    status: "confirmed",
    miner: "0x3a7b...e92f",
  },
  {
    id: "0x2f56a8",
    timestamp: "45 mins ago",
    reward: "0.25 XEN",
    difficulty: "0.9",
    status: "confirmed",
    miner: "0x3a7b...e92f",
  },
  {
    id: "0x7c91e3",
    timestamp: "1 hour ago",
    reward: "0.25 XEN",
    difficulty: "0.9",
    status: "confirmed",
    miner: "0x3a7b...e92f",
  },
]

export function RecentBlocks() {
  return (
    <Card className="border-gray-800 bg-black/50 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Blocks className="h-5 w-5 text-yellow-400" />
            Recent Blocks
          </CardTitle>
          <Badge variant="outline" className="border-yellow-900 text-yellow-400">
            Live
          </Badge>
        </div>
        <CardDescription className="text-gray-400">Latest blocks mined by your node</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentBlocks.map((block) => (
            <div
              key={block.id}
              className="flex items-center justify-between border-b border-gray-800 pb-3 last:border-0 last:pb-0"
            >
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm text-yellow-400">{block.id}</span>
                  <Badge variant="secondary" className="bg-green-900/30 text-green-400 hover:bg-green-900/50">
                    <Check className="mr-1 h-3 w-3" />
                    {block.status}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-400 mt-1">
                  <Clock className="h-3 w-3" />
                  {block.timestamp}
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-medium text-white">{block.reward}</div>
                <div className="text-xs text-gray-400">Miner: {block.miner}</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
