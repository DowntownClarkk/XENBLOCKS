"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Area, AreaChart, Bar, BarChart, Line, LineChart, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

// Sample data
const hourlyData = [
  { time: "00:00", hashrate: 42, blocks: 3, difficulty: 1.2 },
  { time: "01:00", hashrate: 38, blocks: 2, difficulty: 1.3 },
  { time: "02:00", hashrate: 35, blocks: 2, difficulty: 1.3 },
  { time: "03:00", hashrate: 30, blocks: 1, difficulty: 1.4 },
  { time: "04:00", hashrate: 32, blocks: 2, difficulty: 1.4 },
  { time: "05:00", hashrate: 36, blocks: 3, difficulty: 1.3 },
  { time: "06:00", hashrate: 40, blocks: 3, difficulty: 1.3 },
  { time: "07:00", hashrate: 45, blocks: 4, difficulty: 1.2 },
  { time: "08:00", hashrate: 50, blocks: 4, difficulty: 1.2 },
  { time: "09:00", hashrate: 55, blocks: 5, difficulty: 1.1 },
  { time: "10:00", hashrate: 58, blocks: 5, difficulty: 1.1 },
  { time: "11:00", hashrate: 62, blocks: 6, difficulty: 1.0 },
  { time: "12:00", hashrate: 65, blocks: 6, difficulty: 1.0 },
  { time: "13:00", hashrate: 68, blocks: 7, difficulty: 0.9 },
  { time: "14:00", hashrate: 72, blocks: 7, difficulty: 0.9 },
  { time: "15:00", hashrate: 75, blocks: 8, difficulty: 0.8 },
  { time: "16:00", hashrate: 78, blocks: 8, difficulty: 0.8 },
  { time: "17:00", hashrate: 80, blocks: 8, difficulty: 0.8 },
  { time: "18:00", hashrate: 82, blocks: 9, difficulty: 0.7 },
  { time: "19:00", hashrate: 85, blocks: 9, difficulty: 0.7 },
  { time: "20:00", hashrate: 88, blocks: 9, difficulty: 0.7 },
  { time: "21:00", hashrate: 85, blocks: 8, difficulty: 0.8 },
  { time: "22:00", hashrate: 82, blocks: 8, difficulty: 0.8 },
  { time: "23:00", hashrate: 78, blocks: 7, difficulty: 0.9 },
]

const dailyData = [
  { date: "Mon", hashrate: 45, blocks: 42, difficulty: 1.2 },
  { date: "Tue", hashrate: 52, blocks: 48, difficulty: 1.1 },
  { date: "Wed", hashrate: 58, blocks: 53, difficulty: 1.0 },
  { date: "Thu", hashrate: 63, blocks: 57, difficulty: 0.9 },
  { date: "Fri", hashrate: 70, blocks: 65, difficulty: 0.8 },
  { date: "Sat", hashrate: 78, blocks: 72, difficulty: 0.7 },
  { date: "Sun", hashrate: 82, blocks: 76, difficulty: 0.7 },
]

const weeklyData = [
  { week: "Week 1", hashrate: 48, blocks: 320, difficulty: 1.2 },
  { week: "Week 2", hashrate: 52, blocks: 345, difficulty: 1.1 },
  { week: "Week 3", hashrate: 58, blocks: 380, difficulty: 1.0 },
  { week: "Week 4", hashrate: 65, blocks: 410, difficulty: 0.9 },
]

export function MiningChart() {
  const [activeTab, setActiveTab] = useState("hashrate")
  const [timeframe, setTimeframe] = useState("hourly")

  const data = timeframe === "hourly" ? hourlyData : timeframe === "daily" ? dailyData : weeklyData
  const xKey = timeframe === "hourly" ? "time" : timeframe === "daily" ? "date" : "week"

  return (
    <Card className="border-gray-800 bg-black/50 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white">Mining Performance</CardTitle>
          <Tabs value={timeframe} onValueChange={setTimeframe} className="w-auto">
            <TabsList className="bg-gray-900">
              <TabsTrigger
                value="hourly"
                className="data-[state=active]:bg-yellow-900/50 data-[state=active]:text-yellow-400"
              >
                Hourly
              </TabsTrigger>
              <TabsTrigger
                value="daily"
                className="data-[state=active]:bg-yellow-900/50 data-[state=active]:text-yellow-400"
              >
                Daily
              </TabsTrigger>
              <TabsTrigger
                value="weekly"
                className="data-[state=active]:bg-yellow-900/50 data-[state=active]:text-yellow-400"
              >
                Weekly
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        <CardDescription className="text-gray-400">Monitor your mining performance metrics over time</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-gray-900 mb-4">
            <TabsTrigger
              value="hashrate"
              className="data-[state=active]:bg-yellow-900/50 data-[state=active]:text-yellow-400"
            >
              Hashrate
            </TabsTrigger>
            <TabsTrigger
              value="blocks"
              className="data-[state=active]:bg-yellow-900/50 data-[state=active]:text-yellow-400"
            >
              Blocks Mined
            </TabsTrigger>
            <TabsTrigger
              value="difficulty"
              className="data-[state=active]:bg-yellow-900/50 data-[state=active]:text-yellow-400"
            >
              Difficulty
            </TabsTrigger>
          </TabsList>
          <TabsContent value="hashrate" className="h-[300px] mt-0">
            <ChartContainer
              config={{
                hashrate: {
                  label: "Hashrate (MH/s)",
                  color: "hsl(45, 100%, 50%)",
                },
              }}
            >
              <AreaChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id="hashrateGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FFD700" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#FFD700" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey={xKey} stroke="#6b7280" tick={{ fill: "#9ca3af" }} />
                <YAxis stroke="#6b7280" tick={{ fill: "#9ca3af" }} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Area
                  type="monotone"
                  dataKey="hashrate"
                  stroke="#FFD700"
                  fillOpacity={1}
                  fill="url(#hashrateGradient)"
                />
              </AreaChart>
            </ChartContainer>
          </TabsContent>
          <TabsContent value="blocks" className="h-[300px] mt-0">
            <ChartContainer
              config={{
                blocks: {
                  label: "Blocks Mined",
                  color: "hsl(45, 100%, 50%)",
                },
              }}
            >
              <BarChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <XAxis dataKey={xKey} stroke="#6b7280" tick={{ fill: "#9ca3af" }} />
                <YAxis stroke="#6b7280" tick={{ fill: "#9ca3af" }} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="blocks" fill="#FFD700" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ChartContainer>
          </TabsContent>
          <TabsContent value="difficulty" className="h-[300px] mt-0">
            <ChartContainer
              config={{
                difficulty: {
                  label: "Difficulty",
                  color: "hsl(45, 100%, 50%)",
                },
              }}
            >
              <LineChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <XAxis dataKey={xKey} stroke="#6b7280" tick={{ fill: "#9ca3af" }} />
                <YAxis stroke="#6b7280" tick={{ fill: "#9ca3af" }} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line
                  type="monotone"
                  dataKey="difficulty"
                  stroke="#FFD700"
                  strokeWidth={2}
                  dot={{ fill: "#FFD700", r: 4 }}
                  activeDot={{ r: 6, fill: "#FFFFFF" }}
                />
              </LineChart>
            </ChartContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
