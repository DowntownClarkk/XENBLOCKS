"use client"
import { Home, BarChart3, Blocks, Coins, Settings, Users } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"

export function CustomSidebar() {
  return (
    <Sidebar className="bg-black border-r border-yellow-900">
      <SidebarHeader className="border-b border-yellow-900">
        <div className="flex items-center gap-2 px-4 py-2">
          <Blocks className="h-6 w-6 text-yellow-400" />
          <h2 className="text-xl font-bold text-yellow-400">XenBlocks</h2>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-yellow-500">Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild
                  isActive={true}
                  className="text-yellow-400 hover:bg-yellow-900/30 hover:text-yellow-300 data-[active=true]:bg-yellow-900/50 data-[active=true]:text-yellow-300"
                >
                  <a href="#">
                    <Home className="h-4 w-4" />
                    <span>Dashboard</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild
                  className="text-yellow-400 hover:bg-yellow-900/30 hover:text-yellow-300 data-[active=true]:bg-yellow-900/50 data-[active=true]:text-yellow-300"
                >
                  <a href="#">
                    <BarChart3 className="h-4 w-4" />
                    <span>Analytics</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild
                  className="text-yellow-400 hover:bg-yellow-900/30 hover:text-yellow-300 data-[active=true]:bg-yellow-900/50 data-[active=true]:text-yellow-300"
                >
                  <a href="#">
                    <Blocks className="h-4 w-4" />
                    <span>Blocks</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild
                  className="text-yellow-400 hover:bg-yellow-900/30 hover:text-yellow-300 data-[active=true]:bg-yellow-900/50 data-[active=true]:text-yellow-300"
                >
                  <a href="#">
                    <Coins className="h-4 w-4" />
                    <span>Rewards</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <SidebarGroup>
          <SidebarGroupLabel className="text-yellow-500">System</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild
                  className="text-yellow-400 hover:bg-yellow-900/30 hover:text-yellow-300 data-[active=true]:bg-yellow-900/50 data-[active=true]:text-yellow-300"
                >
                  <a href="#">
                    <Users className="h-4 w-4" />
                    <span>Miners</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild
                  className="text-yellow-400 hover:bg-yellow-900/30 hover:text-yellow-300 data-[active=true]:bg-yellow-900/50 data-[active=true]:text-yellow-300"
                >
                  <a href="#">
                    <Settings className="h-4 w-4" />
                    <span>Settings</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t border-yellow-900 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-yellow-400 flex items-center justify-center text-black font-bold">
              D
            </div>
            <div className="text-yellow-400">
              <div className="text-xs text-gray-400">Designed by</div>
              <div>DowntownClarkk</div>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="border-yellow-900 text-yellow-400 hover:bg-yellow-900/30 hover:text-yellow-300"
          >
            Settings
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
