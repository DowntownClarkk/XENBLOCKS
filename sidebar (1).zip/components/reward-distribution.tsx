"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Cell, Pie, PieChart } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

// Sample data
const data = [
  { name: "Mining Rewards", value: 65, color: "#FFD700" },
  { name: "Staking Rewards", value: 20, color: "#FFA500" },
  { name: "Referral Bonus", value: 10, color: "#FF8C00" },
  { name: "Other", value: 5, color: "#FF4500" },
]

export function RewardDistribution() {
  return (
    <Card className="border-gray-800 bg-black/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-white">Reward Distribution</CardTitle>
        <CardDescription className="text-gray-400">Breakdown of your XenBlock rewards</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[200px]">
          <ChartContainer
            config={{
              "Mining Rewards": {
                label: "Mining Rewards",
                color: "#FFD700",
              },
              "Staking Rewards": {
                label: "Staking Rewards",
                color: "#FFA500",
              },
              "Referral Bonus": {
                label: "Referral Bonus",
                color: "#FF8C00",
              },
              Other: {
                label: "Other",
                color: "#FF4500",
              },
            }}
          >
            <PieChart>
              <Pie data={data} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <ChartTooltip content={<ChartTooltipContent />} />
            </PieChart>
          </ChartContainer>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-4">
          {data.map((item) => (
            <div key={item.name} className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
              <div className="text-xs">
                <span className="text-gray-200">{item.name}</span>
                <span className="text-gray-400 ml-1">({item.value}%)</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
