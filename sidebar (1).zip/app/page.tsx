"use client"

import { Blocks, Coins, Cpu, Zap } from "lucide-react"
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"
import { CustomSidebar } from "@/components/custom-sidebar"
import { StatsCard } from "@/components/stats-card"
import { MiningChart } from "@/components/mining-chart"
import { RecentBlocks } from "@/components/recent-blocks"
import { RewardDistribution } from "@/components/reward-distribution"
import { WelcomeCard } from "@/components/welcome-card"

export default function Home() {
  return (
    <div className="bg-black min-h-screen w-full">
      <SidebarProvider className="bg-black">
        <div className="flex min-h-screen w-full">
          <CustomSidebar />
          <div className="flex-1 p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-white">
                  XenBlocks <span className="text-yellow-400">Dashboard</span>
                </h1>
                <p className="text-gray-400">
                  Created by <span className="text-yellow-400 font-medium">DowntownClarkk</span>
                </p>
              </div>
              <SidebarTrigger className="text-white hover:bg-gray-800" />
            </div>

            {/* Welcome Card */}
            <div className="mb-6">
              <WelcomeCard />
            </div>

            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <StatsCard
                title="Hashrate"
                value="82 MH/s"
                icon={<Zap className="h-4 w-4" />}
                trend={{ value: 12, isPositive: true }}
              />
              <StatsCard
                title="Blocks Mined"
                value="1,248"
                icon={<Blocks className="h-4 w-4" />}
                trend={{ value: 8, isPositive: true }}
              />
              <StatsCard
                title="Total Rewards"
                value="312 XEN"
                icon={<Coins className="h-4 w-4" />}
                trend={{ value: 5, isPositive: true }}
              />
              <StatsCard
                title="Active Miners"
                value="3"
                icon={<Cpu className="h-4 w-4" />}
                description="All miners online"
              />
            </div>

            {/* Mining Performance Chart */}
            <div className="mb-6">
              <MiningChart />
            </div>

            {/* Bottom Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <RecentBlocks />
              <RewardDistribution />
            </div>

            {/* Footer */}
            <div className="mt-8 text-center text-xs text-gray-500">
              <p>XenBlocks Dashboard • Designed by DowntownClarkk • © 2025</p>
            </div>
          </div>
        </div>
      </SidebarProvider>
    </div>
  )
}
